/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package timetableapp;

/**
 *
 * @author emmak
 */
public class CampusClass extends Timetable{
    
     private int roomNo;

    public CampusClass(int roomNo, String day, String time, String lecName, String duration) {
        super(day, time, lecName, duration);
        this.roomNo = roomNo;
    }
    
    public CampusClass() {
        super();
        roomNo = ' ';
    }

    public int getRoomNo() {
        return roomNo;
    }

    public void setRoomNo(int roomNo) {
        this.roomNo = roomNo;
    }

    public String getDay() {
        return day;
    }

    public void setDay(String day) {
        this.day = day;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getLecName() {
        return lecName;
    }

    public void setLecName(String lecName) {
        this.lecName = lecName;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }


        public String printDetails() {
        return super.PrintDetails() + ", Room Number: " + roomNo;
    }
    
}
