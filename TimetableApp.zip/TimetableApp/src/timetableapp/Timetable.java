/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package timetableapp;

import java.io.Serializable;

/**
 *
 * @author emmak
 */
public class Timetable implements Serializable {

    protected String day;
    protected String time;
    protected String lecName;
    protected String duration;

    public Timetable(String day, String time, String lecName, String duration) {
        this.day = day;
        this.time = time;
        this.lecName = lecName;
        this.duration = duration;
    }

    public Timetable() {
        day = " ";
        time = " ";
        lecName = " ";
        duration = " ";

    }

    public String getDay() {
        return day;
    }

    public void setDay(String day) {
        this.day = day;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getLecName() {
        return lecName;
    }

    public void setLecName(String lecName) {
        this.lecName = lecName;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }


    
    public String PrintDetails() {
        return "Day: " + day + ", Time: " + time + ", Lecturer Name: " + lecName + ", Duration (mins): " + duration;
    }

}
