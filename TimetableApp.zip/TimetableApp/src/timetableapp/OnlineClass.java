/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package timetableapp;

/**
 *
 * @author emmak
 */
public class OnlineClass extends Timetable{
    
       private String url;

    public OnlineClass(String url, String day, String time, String lecName, String duration) {
        super(day, time, lecName, duration);
        this.url = url;
    }

    public OnlineClass() {
        super();
        url = " ";
    }

    public String getFormat() {
        return url;
    }

    public void setFormat(String format) {
        this.url = format;
    }

    public String getDay() {
        return day;
    }

    public void setDay(String day) {
        this.day = day;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getLecName() {
        return lecName;
    }

    public void setLecName(String lecName) {
        this.lecName = lecName;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }



    public String printDetails() {
        return super.PrintDetails() + ", URL: " + url;
    }
    
    
}
